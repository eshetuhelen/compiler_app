/* A Bison parser, made by GNU Bison 2.7.  */

/* Bison interface for Yacc-like parsers in C
   
      Copyright (C) 1984, 1989-1990, 2000-2012 Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

#ifndef YY_YY_Y_TAB_H_INCLUDED
# define YY_YY_Y_TAB_H_INCLUDED
/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     ID = 258,
     STRINGL = 259,
     NUMBER = 260,
     FLOATN = 261,
     CHARL = 262,
     FUNC = 263,
     VAR = 264,
     PACKAGE = 265,
     IMPORT = 266,
     TYPE = 267,
     STRUCT = 268,
     VOID = 269,
     INT = 270,
     FLOAT = 271,
     BOOL = 272,
     STRING = 273,
     CHAR = 274,
     IF = 275,
     ELSE = 276,
     FOR = 277,
     RETURN = 278,
     SWITCH = 279,
     CASE = 280,
     DEFAULT = 281,
     FMT_PRINTLN = 282,
     FMT_PRINTF = 283,
     FMT_SCANF = 284,
     TRUE = 285,
     FALSE = 286,
     ADD = 287,
     SUBTRACT = 288,
     MULTIPLY = 289,
     DIVIDE = 290,
     MOD = 291,
     NOT = 292,
     EQ = 293,
     NE = 294,
     GT = 295,
     LT = 296,
     AND = 297,
     OR = 298,
     ASSIGN = 299,
     SEMICOLON = 300,
     INCREMENT = 301,
     DECREMENT = 302,
     LPAREN = 303,
     RPAREN = 304,
     LBRACE = 305,
     RBRACE = 306,
     COMMA = 307,
     DOT = 308,
     COLON = 309,
     UNARY = 310
   };
#endif
/* Tokens.  */
#define ID 258
#define STRINGL 259
#define NUMBER 260
#define FLOATN 261
#define CHARL 262
#define FUNC 263
#define VAR 264
#define PACKAGE 265
#define IMPORT 266
#define TYPE 267
#define STRUCT 268
#define VOID 269
#define INT 270
#define FLOAT 271
#define BOOL 272
#define STRING 273
#define CHAR 274
#define IF 275
#define ELSE 276
#define FOR 277
#define RETURN 278
#define SWITCH 279
#define CASE 280
#define DEFAULT 281
#define FMT_PRINTLN 282
#define FMT_PRINTF 283
#define FMT_SCANF 284
#define TRUE 285
#define FALSE 286
#define ADD 287
#define SUBTRACT 288
#define MULTIPLY 289
#define DIVIDE 290
#define MOD 291
#define NOT 292
#define EQ 293
#define NE 294
#define GT 295
#define LT 296
#define AND 297
#define OR 298
#define ASSIGN 299
#define SEMICOLON 300
#define INCREMENT 301
#define DECREMENT 302
#define LPAREN 303
#define RPAREN 304
#define LBRACE 305
#define RBRACE 306
#define COMMA 307
#define DOT 308
#define COLON 309
#define UNARY 310



#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{
/* Line 2058 of yacc.c  */
#line 21 "parser.y"

    char* strval;
    int intval;
    float floatval;
    char charval;


/* Line 2058 of yacc.c  */
#line 175 "y.tab.h"
} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */

#endif /* !YY_YY_Y_TAB_H_INCLUDED  */
