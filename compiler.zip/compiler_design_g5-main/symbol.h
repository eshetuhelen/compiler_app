#ifndef SYMBOL_H
#define SYMBOL_H

struct symbol_entry {
    char name[50];
    char kind[20];
    int token_type;
    int lineno;
};

extern struct symbol_entry symbol_table[100];
extern int symbol_count;

extern char* token_classes[];

int search_symbol_table(char *name);
void add_to_symbol_table(char *name, int token, int lineno);
void print_symbol_table();
char* search_symbol_Byname(char *name);

#endif