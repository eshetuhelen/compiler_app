package mainu
import "fmt"

type rectangle struct {
	length  float
	breadth float
	color   string
}

// jlh;h;oi

/*  dfgsfg
fdgsdf */

func main() {
	var x int = 1
	var y int = 3

	if x < y {
		fmt.Println("x is less than y")
	} else {
		fmt.Println("x is greater than or equal to y")
	}

	for i = 0; i < 5; i++ {
		fmt.Println(i)
	}

}