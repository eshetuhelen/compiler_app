#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symbol.h"

char * token_classes[] = {
      "VAR",
      "FUNC",
      "PACKAGE",
      "IMPORT",
      "STRUCT",
      "TYPE",
      "VOID",
      "INT",
      "FLOAT",
      "BOOL",
      "STRING",
      "CHAR",
      "IF",
      "ELSE",
      "FOR",
      "RETURN",
      "FMT_PRINTLN",
      "FMT_PRINTF",
      "FMT_SCANF",
      "TRUE",
      "FALSE",
      "ID",
      "NUMBER",
      "FLOATN",
      "STRINGL",
      "CHARL",
      "ADD",
      "SUBTRACT",
      "MULTIPLY",
      "DIVIDE",
      "MOD",
      "NOT",
      "EQ",
      "NE",
      "GT",
      "LT",
      "AND",
      "OR",
      "ASSIGN",
      "SEMICOLON",
      "LPAREN",
      "RPAREN",
      "LBRACE",
      "RBRACE",
      "COMMA",
      "DOT",
      "SWITCH",
      "CASE",
      "DEFAULT",
      "COLON",
  };

  struct symbol_entry symbol_table[100];
  int symbol_count = 0;

  int search_symbol_table(char *name) {
      for (int i = 0; i < symbol_count; i++) {
          if (strcmp(symbol_table[i].name, name) == 0)
            return symbol_table[i].token_type; // Return token if found
      }
      return -1; // not found
  }

  void add_to_symbol_table(char *name, int token, int lineno) {
      strcpy(symbol_table[symbol_count].name, name);
      symbol_table[symbol_count].token_type = token;
      symbol_table[symbol_count].lineno = lineno;

      symbol_count++;
  }

  void print_symbol_table() {
    printf("+--------------------+------------+-------------+-------------+\n");
    printf("| Name               | kind       | Token Type  | Line No     |\n");
    printf("+--------------------+------------+-------------+-------------+\n");

    for (int i = 0; i < symbol_count; i++) {
        printf("| %-18s | %-10s | %-11d | %-11d |\n",
        symbol_table[i].name, symbol_table[i].kind, symbol_table[i].token_type, symbol_table[i].lineno);
    }

    printf("+--------------------+------------+-------------+-------------+\n");
 }

  char* search_symbol_Byname(char *name) {
      for (int i = 0; i < symbol_count; i++) {
          if (strcmp(symbol_table[i].name, name) == 0)
              return token_classes[symbol_table[i].token_type]; // Return token name if found
      }
      return "UNKNOWN"; // Return "UNKNOWN" if not found
  }